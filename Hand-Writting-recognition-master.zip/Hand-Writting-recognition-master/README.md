# Hand-Writting-recognition
Mini projects like handwritten integer recognition.
